// 구글 설문지 퀴즈 만들기
// 1) script.google.com → 새 프로젝트 → 이 내용을 모두 붙여 넣기
// 2) 위쪽 '실행' → 권한 검토 → 내 계정 선택
//    '확인되지 않은 앱' 화면이 나오면 '고급' → '(안전하지 않음)으로 이동' → '허용'
//    (내가 붙여 넣은 스크립트가 내 드라이브에 설문지를 만드는 권한입니다)
// 3) 아래 '실행 로그'에 나온 편집 주소와 학생용 주소를 엽니다
// 주관식은 자동 채점 정답을 넣을 수 없어 배점과 정답 안내만 넣습니다.
// 자동 채점하려면 설문지 편집 화면에서 문항마다 '답안'을 눌러 정답을 넣으세요.

function makeQuiz() {
  var form = FormApp.create("중1 과학 · 물질의 상태 변화 확인 퀴즈");
  form.setIsQuiz(true);
  form.setDescription("학습지 1~2쪽 내용입니다. 모르는 문제는 학습지를 다시 보고 풀어 보세요.");
  form.setCollectEmail(false);
  form.setShuffleQuestions(false);
  var item;
  item = form.addMultipleChoiceItem().setTitle("1. 고체 상태에서 입자의 운동으로 옳은 것은?").setPoints(1).setRequired(true);
  item.setChoices([item.createChoice("제자리에서 진동한다", true), item.createChoice("비교적 자유롭게 움직인다", false), item.createChoice("매우 활발하게 움직인다", false), item.createChoice("전혀 움직이지 않는다", false)]);
  item.setFeedbackForCorrect(FormApp.createFeedback().setText("맞았습니다. 고체 입자는 규칙적으로 촘촘하게 놓여 제자리에서 진동합니다. 움직임이 아예 없는 것은 아닙니다.").build());
  item.setFeedbackForIncorrect(FormApp.createFeedback().setText("정답은 1번 '제자리에서 진동한다'입니다. 고체 입자는 규칙적으로 촘촘하게 놓여 제자리에서 진동합니다. 움직임이 아예 없는 것은 아닙니다.").build());
  item = form.addMultipleChoiceItem().setTitle("2. 모양은 담는 그릇에 따라 변하지만 부피는 일정한 상태는?").setPoints(1).setRequired(true);
  item.setChoices([item.createChoice("고체", false), item.createChoice("기체", false), item.createChoice("액체", true), item.createChoice("고체와 기체", false)]);
  item.setFeedbackForCorrect(FormApp.createFeedback().setText("맞았습니다. 액체는 그릇 모양을 따라가지만 부피는 변하지 않습니다.").build());
  item.setFeedbackForIncorrect(FormApp.createFeedback().setText("정답은 3번 '액체'입니다. 액체는 그릇 모양을 따라가지만 부피는 변하지 않습니다.").build());
  item = form.addMultipleChoiceItem().setTitle("3. 촛농이 굳는 현상과 같은 상태 변화는?").setPoints(1).setRequired(true);
  item.setChoices([item.createChoice("융해", false), item.createChoice("응고", true), item.createChoice("액화", false), item.createChoice("기화", false)]);
  item.setFeedbackForCorrect(FormApp.createFeedback().setText("맞았습니다. 액체가 고체로 변하는 것은 응고입니다.").build());
  item.setFeedbackForIncorrect(FormApp.createFeedback().setText("정답은 2번 '응고'입니다. 액체가 고체로 변하는 것은 응고입니다.").build());
  item = form.addMultipleChoiceItem().setTitle("4. 드라이아이스의 크기가 점점 작아지는 까닭으로 옳은 것은?").setPoints(1).setRequired(true);
  item.setChoices([item.createChoice("고체가 액체로 융해되기 때문", false), item.createChoice("액체가 기체로 기화되기 때문", false), item.createChoice("기체가 고체로 승화되기 때문", false), item.createChoice("고체가 기체로 승화되기 때문", true)]);
  item.setFeedbackForCorrect(FormApp.createFeedback().setText("맞았습니다. 드라이아이스는 액체를 거치지 않고 고체에서 바로 기체가 됩니다.").build());
  item.setFeedbackForIncorrect(FormApp.createFeedback().setText("정답은 4번 '고체가 기체로 승화되기 때문'입니다. 드라이아이스는 액체를 거치지 않고 고체에서 바로 기체가 됩니다.").build());
  item = form.addMultipleChoiceItem().setTitle("5. 얼음물이 든 컵 바깥에 물방울이 맺히는 현상은?").setPoints(1).setRequired(true);
  item.setChoices([item.createChoice("기화", false), item.createChoice("액화", true), item.createChoice("융해", false), item.createChoice("승화", false)]);
  item.setFeedbackForCorrect(FormApp.createFeedback().setText("맞았습니다. 공기 중 수증기(기체)가 차가운 컵에 닿아 물(액체)이 되는 액화입니다.").build());
  item.setFeedbackForIncorrect(FormApp.createFeedback().setText("정답은 2번 '액화'입니다. 공기 중 수증기(기체)가 차가운 컵에 닿아 물(액체)이 되는 액화입니다.").build());
  item = form.addMultipleChoiceItem().setTitle("6. 상태 변화가 일어날 때 변하지 않는 것은?").setPoints(1).setRequired(true);
  item.setChoices([item.createChoice("질량", true), item.createChoice("부피", false), item.createChoice("입자 배열", false), item.createChoice("입자 사이의 거리", false)]);
  item.setFeedbackForCorrect(FormApp.createFeedback().setText("맞았습니다. 입자의 종류와 개수가 그대로이므로 질량은 변하지 않습니다. 부피는 입자 배열이 달라져 변합니다.").build());
  item.setFeedbackForIncorrect(FormApp.createFeedback().setText("정답은 1번 '질량'입니다. 입자의 종류와 개수가 그대로이므로 질량은 변하지 않습니다. 부피는 입자 배열이 달라져 변합니다.").build());
  item = form.addMultipleChoiceItem().setTitle("7. 열에너지를 방출하는 상태 변화끼리 짝 지은 것은?").setPoints(1).setRequired(true);
  item.setChoices([item.createChoice("융해, 기화", false), item.createChoice("기화, 액화", false), item.createChoice("융해, 응고", false), item.createChoice("응고, 액화", true)]);
  item.setFeedbackForCorrect(FormApp.createFeedback().setText("맞았습니다. 응고, 액화, 승화(기체→고체)는 열에너지를 방출합니다.").build());
  item.setFeedbackForIncorrect(FormApp.createFeedback().setText("정답은 4번 '응고, 액화'입니다. 응고, 액화, 승화(기체→고체)는 열에너지를 방출합니다.").build());
  item = form.addMultipleChoiceItem().setTitle("8. 더운 날 마당에 물을 뿌리면 시원해지는 까닭은?").setPoints(1).setRequired(true);
  item.setChoices([item.createChoice("물이 응고하며 열에너지를 방출하기 때문", false), item.createChoice("물이 액화하며 열에너지를 흡수하기 때문", false), item.createChoice("물이 기화하며 열에너지를 흡수하기 때문", true), item.createChoice("물이 기화하며 열에너지를 방출하기 때문", false)]);
  item.setFeedbackForCorrect(FormApp.createFeedback().setText("맞았습니다. 물이 기화할 때 주변의 열에너지를 흡수해 주변 온도가 낮아집니다.").build());
  item.setFeedbackForIncorrect(FormApp.createFeedback().setText("정답은 3번 '물이 기화하며 열에너지를 흡수하기 때문'입니다. 물이 기화할 때 주변의 열에너지를 흡수해 주변 온도가 낮아집니다.").build());
  item = form.addMultipleChoiceItem().setTitle("9. 얼음이 녹는 동안의 온도에 대한 설명으로 옳은 것은?").setPoints(1).setRequired(true);
  item.setChoices([item.createChoice("가한 열에너지가 상태 변화에 쓰여 온도가 일정하다", true), item.createChoice("온도가 계속 올라간다", false), item.createChoice("온도가 계속 내려간다", false), item.createChoice("온도가 오르내리기를 반복한다", false)]);
  item.setFeedbackForCorrect(FormApp.createFeedback().setText("맞았습니다. 녹는 동안에는 열에너지가 상태 변화에 쓰여 온도가 녹는점에서 일정합니다.").build());
  item.setFeedbackForIncorrect(FormApp.createFeedback().setText("정답은 1번 '가한 열에너지가 상태 변화에 쓰여 온도가 일정하다'입니다. 녹는 동안에는 열에너지가 상태 변화에 쓰여 온도가 녹는점에서 일정합니다.").build());
  item = form.addMultipleChoiceItem().setTitle("10. 녹는점과 끓는점으로 물질을 구별할 수 있는 까닭은?").setPoints(1).setRequired(true);
  item.setChoices([item.createChoice("모든 물질의 끓는점이 100 ℃이기 때문", false), item.createChoice("녹는점과 어는점이 서로 다르기 때문", false), item.createChoice("물질의 양이 많을수록 녹는점이 높아지기 때문", false), item.createChoice("녹는점과 끓는점은 물질마다 다르기 때문", true)]);
  item.setFeedbackForCorrect(FormApp.createFeedback().setText("맞았습니다. 녹는점과 끓는점은 물질마다 정해져 있어 물질을 구별하는 데 씁니다. 같은 물질의 녹는점과 어는점은 같습니다.").build());
  item.setFeedbackForIncorrect(FormApp.createFeedback().setText("정답은 4번 '녹는점과 끓는점은 물질마다 다르기 때문'입니다. 녹는점과 끓는점은 물질마다 정해져 있어 물질을 구별하는 데 씁니다. 같은 물질의 녹는점과 어는점은 같습니다.").build());
  item = form.addTextItem().setTitle("11. 고체가 액체로 변하는 현상을 무엇이라고 하나요? (두 글자)").setPoints(1).setRequired(true);
  item.setGeneralFeedback(FormApp.createFeedback().setText("정답: 융해. 얼음이 녹아 물이 되는 것이 융해입니다. 설탕이 물에 녹는 '용해'와 헷갈리지 않도록 합니다.").build());
  item = form.addTextItem().setTitle("12. 추운 겨울 아침 풀잎에 서리가 생기는 것처럼 기체가 고체로 바로 변하는 현상은? (두 글자)").setPoints(1).setRequired(true);
  item.setGeneralFeedback(FormApp.createFeedback().setText("정답: 승화. 고체→기체와 기체→고체 모두 승화라고 합니다.").build());
  item = form.addTextItem().setTitle("13. 같은 물질에서 녹는점과 온도가 같은 것은? (세 글자)").setPoints(1).setRequired(true);
  item.setGeneralFeedback(FormApp.createFeedback().setText("정답: 어는점. 물의 녹는점과 어는점은 모두 0 ℃입니다.").build());
  item = form.addTextItem().setTitle("14. 1기압에서 물의 끓는점은 몇 ℃인가요? (숫자만)").setPoints(1).setRequired(true);
  item.setGeneralFeedback(FormApp.createFeedback().setText("정답: 100 또는 100℃ 또는 100 ℃. 물은 1기압에서 100 ℃에서 끓습니다.").build());
  item = form.addTextItem().setTitle("15. 겨울에 수도관이 터지는 것은 물이 얼 때 무엇이 늘어나기 때문인가요? (두 글자)").setPoints(1).setRequired(true);
  item.setGeneralFeedback(FormApp.createFeedback().setText("정답: 부피. 물은 다른 물질과 달리 얼 때 부피가 늘어납니다. 질량은 변하지 않습니다.").build());
  item = form.addTextItem().setTitle("16. 젖은 빨래가 마르는 것처럼 액체가 기체로 변하는 현상은? (두 글자)").setPoints(1).setRequired(true);
  item.setGeneralFeedback(FormApp.createFeedback().setText("정답: 기화. 물이 수증기가 되어 공기 중으로 날아가는 기화입니다.").build());
  Logger.log('편집 주소: ' + form.getEditUrl());
  Logger.log('학생용 주소: ' + form.getPublishedUrl());
}
