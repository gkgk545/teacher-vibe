"""한글(hwpx) 양식의 글자만 바꿔 새 hwpx를 만든다. 파이썬 기본 기능만 쓴다(설치할 것 없음).

사용법
  python hwpx_tool.py dump  양식.hwpx              # 바꿀 수 있는 곳의 번호와 지금 글자를 보여 준다
  python hwpx_tool.py fill  양식.hwpx 내용.json 결과.hwpx
  python hwpx_tool.py text  결과.hwpx              # 결과 글자만 뽑아 점검한다

내용.json 형식
{
  "paragraphs": {"5": "본문 문단 글자", "12": "2026. 11. 16."},
  "cells": {"0:1:1": "표0 1행 1열 칸 글자", "2:1:0": "여러 줄은\\n로 나눈다"},
  "tables": {
    "1": {"header_rows": 1, "merge_cols": [0, 1],
          "rows": [["1교시", "09:00~09:45", "국어 교사", "1-1", "(국어) 시 낭송", "1-1 교실"], ...]}
  }
}
- paragraphs: dump에 [문단 n]으로 나온 표 밖 문단(글상자 안 포함).
  값이 목록이면 ‖로 나뉜 글자 조각마다 따로 넣어 굵기 같은 모양을 지킨다
- cells: "표:행:열" (행·열은 dump의 주소). 칸 구조는 그대로 두고 글자만 바꾼다
- tables: 표의 데이터 행을 통째로 다시 만든다. 행 수가 양식과 달라도 된다.
  merge_cols에 든 열은 위 행과 값이 같으면 세로로 합친다(예: 같은 교시·시간)
"""
import json
import re
import sys
import zipfile
from xml.sax.saxutils import escape

SECTION = "Contents/section0.xml"


# ---------- 문단·표 위치 찾기 ----------

def text_paragraphs(x):
    """표 칸 밖에서 글자를 담는 문단(안에 다른 문단이 없는 것)의 (시작, 끝) 목록. 글상자 안 문단도 포함한다."""
    tables = find_tables(x)
    out, stack = [], []
    for m in re.finditer(r"<hp:p [^>]*>|</hp:p>", x):
        if m.group(0).startswith("</"):
            start, has_child = stack.pop()
            if stack:
                stack[-1][1] = True
            if not has_child and not any(ts <= start < te for ts, te in tables):
                out.append((start, m.end()))
        else:
            stack.append([m.start(), False])
    return sorted(out)


def text_runs(p):
    return re.findall(r"<hp:t>(.*?)</hp:t>", p, re.S)


def find_tables(x):
    out, pos = [], 0
    while True:
        s = x.find("<hp:tbl ", pos)
        if s < 0:
            return out
        e = x.find("</hp:tbl>", s) + len("</hp:tbl>")
        out.append((s, e))
        pos = e


def rows_of(tbl):
    return [(m.start(), m.end()) for m in re.finditer(r"<hp:tr>.*?</hp:tr>", tbl, re.S)]


def cells_of(tr):
    return [(m.start(), m.end()) for m in re.finditer(r"<hp:tc .*?</hp:tc>", tr, re.S)]


def cell_addr(tc):
    c, r = re.search(r'<hp:cellAddr colAddr="(\d+)" rowAddr="(\d+)"/>', tc).groups()
    return int(r), int(c)


def plain_text(xml):
    parts = []
    for p in re.findall(r"<hp:p [^>]*>.*?</hp:p>", xml, re.S):
        t = "".join(re.findall(r"<hp:t>(.*?)</hp:t>", p, re.S))
        t = re.sub(r"<hp:tab[^>]*/>", "\t", t)
        t = re.sub(r"<[^>]+>", "", t)
        parts.append(t.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&"))
    return "\n".join(parts)


# ---------- 글자 바꾸기 ----------

def set_para_text(p, text):
    """문단 하나의 글자를 바꾼다.
    text가 문자열이면 첫 글자 조각의 모양을 따라 한 덩어리로 넣는다.
    text가 목록이면 글자 조각(dump의 ‖로 나뉜 부분)마다 차례로 넣어 굵기 같은 모양을 지킨다."""
    p = re.sub(r"<hp:linesegarray>.*?</hp:linesegarray>", "", p, flags=re.S)
    if isinstance(text, list):
        items = iter(text)

        def rep_each(m):
            try:
                return "<hp:t>%s</hp:t>" % escape(next(items))
            except StopIteration:
                return "<hp:t/>"

        n = len(re.findall(r"<hp:t>.*?</hp:t>|<hp:t/>", p, re.S))
        if len(text) > n:
            raise ValueError("글자 조각은 %d개인데 %d개를 넣으려 했습니다" % (n, len(text)))
        return re.sub(r"<hp:t>.*?</hp:t>|<hp:t/>", rep_each, p, flags=re.S)
    new_t = "<hp:t>%s</hp:t>" % escape(text)
    if re.search(r"<hp:t>.*?</hp:t>|<hp:t/>", p, re.S):
        first = [True]

        def rep(m):
            if first[0]:
                first[0] = False
                return new_t
            return ""

        p = re.sub(r"<hp:t>.*?</hp:t>|<hp:t/>", rep, p, flags=re.S)
        p = re.sub(r'<hp:run charPrIDRef="\d+">\s*</hp:run>', "", p)
        return p
    m = re.search(r'<hp:run charPrIDRef="(\d+)"/>', p)
    if m:
        return p.replace(m.group(0), '<hp:run charPrIDRef="%s">%s</hp:run>' % (m.group(1), new_t), 1)
    m = re.search(r"</hp:run>", p)
    if m:
        return p[: m.start()] + new_t + p[m.start():]
    raise ValueError("글자를 넣을 수 없는 문단입니다")


def set_cell_text(tc, text):
    """칸의 글자를 바꾼다. 여러 줄이면 첫 문단 모양을 복사해 문단을 늘린다."""
    paras = re.findall(r"<hp:p [^>]*>.*?</hp:p>", tc, re.S)
    tmpl = paras[0]
    new = "".join(set_para_text(tmpl, line) for line in text.split("\n"))
    s = tc.find(paras[0])
    e = tc.find(paras[-1]) + len(paras[-1])
    return tc[:s] + new + tc[e:]


def set_cell_layout(tc, row, col, row_span, height):
    tc = re.sub(r'<hp:cellAddr colAddr="\d+" rowAddr="\d+"/>',
                '<hp:cellAddr colAddr="%d" rowAddr="%d"/>' % (col, row), tc)
    tc = re.sub(r'(<hp:cellSpan colSpan="\d+" rowSpan=")\d+("/>)', r"\g<1>%d\2" % row_span, tc)
    tc = re.sub(r'(<hp:cellSz width="\d+" height=")\d+("/>)', r"\g<1>%d\2" % height, tc)
    return tc


def rebuild_table(tbl, spec):
    """데이터 행을 다시 만든다. 첫 데이터 행의 칸 모양을 열마다 본으로 쓴다."""
    header_rows = spec.get("header_rows", 1)
    merge_cols = set(spec.get("merge_cols", []))
    data = spec["rows"]
    rws = rows_of(tbl)
    head = [tbl[s:e] for s, e in rws[:header_rows]]
    body = [tbl[s:e] for s, e in rws[header_rows:]]

    # 열마다 본이 될 칸: 합치지 않는 열은 합쳐지지 않은 칸(이어지는 행)에서, 합치는 열은 첫 행에서 고른다
    tmpl, base_h = {}, None
    for tr in body:
        for s, e in cells_of(tr):
            tc = tr[s:e]
            _, c = cell_addr(tc)
            span = int(re.search(r'rowSpan="(\d+)"', tc).group(1))
            h = int(re.search(r'<hp:cellSz width="\d+" height="(\d+)"/>', tc).group(1))
            if span == 1:
                base_h = base_h or h
                if c not in tmpl or c not in merge_cols:
                    tmpl.setdefault(c, tc)
            elif c not in tmpl:
                tmpl[c] = tc
    ncol = max(tmpl) + 1
    if any(len(r) != ncol for r in data):
        raise ValueError("행마다 칸이 %d개여야 합니다" % ncol)

    # 합칠 구간 계산: 합치는 열의 값이 모두 같은 연속 행을 한 묶음으로 본다
    def key(r):
        return tuple(r[c] for c in sorted(merge_cols))

    span_at, i = {}, 0
    while i < len(data):
        j = i
        while j + 1 < len(data) and merge_cols and key(data[j + 1]) == key(data[i]):
            j += 1
        span_at[i] = j - i + 1
        for k in range(i + 1, j + 1):
            span_at[k] = 0
        i = j + 1

    trs = []
    for ri, r in enumerate(data):
        row_no = header_rows + ri
        tcs = []
        for c in range(ncol):
            if c in merge_cols:
                if span_at[ri] == 0:
                    continue
                span = span_at[ri]
            else:
                span = 1
            tc = set_cell_text(tmpl[c], str(r[c]))
            tc = set_cell_layout(tc, row_no, c, span, base_h * span)
            tcs.append(tc)
        trs.append("<hp:tr>" + "".join(tcs) + "</hp:tr>")

    s0 = rws[0][0]
    e_last = rws[-1][1]
    out = tbl[:s0] + "".join(head) + "".join(trs) + tbl[e_last:]
    out = re.sub(r'rowCnt="\d+"', 'rowCnt="%d"' % (header_rows + len(data)), out, count=1)
    head_h = sum(int(re.search(r'<hp:cellSz width="\d+" height="(\d+)"/>', h).group(1)) for h in head)
    total = head_h + base_h * len(data)
    old_total = int(re.search(r'<hp:sz width="\d+" widthRelTo="\w+" height="(\d+)"', out).group(1))
    out = re.sub(r'(<hp:sz width="\d+" widthRelTo="\w+" height=")\d+(")', r"\g<1>%d\2" % total, out, count=1)
    return out, total - old_total


def grow_box(x, tbl_start, delta):
    """표를 감싼 글상자(사각형)가 있으면 표가 늘어난 만큼 키운다. 안 키우면 넘친 행이 잘려 보인다."""
    s = x.rfind("<hp:rect ", 0, tbl_start)
    if s < 0 or x.find("</hp:rect>", s) < tbl_start:
        return x
    e = x.find("</hp:rect>", s)
    r = x[s:e]
    org_h = int(re.search(r'<hp:orgSz width="\d+" height="(\d+)"/>', r).group(1))
    cur_h = int(re.search(r'<hp:curSz width="\d+" height="(\d+)"/>', r).group(1)) + delta
    r = re.sub(r'(<hp:curSz width="\d+" height=")\d+(")', r"\g<1>%d\2" % cur_h, r)
    r = re.sub(r'(<hp:sz width="\d+" widthRelTo="\w+" height=")(\d+)(")',
               lambda m: "%s%d%s" % (m.group(1), int(m.group(2)) + delta, m.group(3)), r)
    r = re.sub(r'(<hc:scaMatrix e1="[\d.]+" e2="0" e3="0" e4="0" e5=")[\d.]+(")',
               r"\g<1>%.6f\2" % (cur_h / org_h), r)
    r = re.sub(r'(centerY=")\d+(")', r"\g<1>%d\2" % (cur_h // 2), r)
    return x[:s] + r + x[e:]


# ---------- 명령 ----------

def read(path):
    with zipfile.ZipFile(path) as z:
        return {n: z.read(n) for n in z.namelist()}, z.namelist()


def write(path, files, order, section_xml):
    files = dict(files)
    files[SECTION] = section_xml.encode("utf-8")
    files["Preview/PrvText.txt"] = plain_text(section_xml).encode("utf-8")
    with zipfile.ZipFile(path, "w") as z:
        for n in order:
            if n == "Preview/PrvImage.png":
                continue  # 옛 미리보기 그림은 뺀다(내용이 달라 헷갈림)
            method = zipfile.ZIP_STORED if n in ("mimetype", "version.xml") else zipfile.ZIP_DEFLATED
            z.writestr(zipfile.ZipInfo(n, date_time=(1980, 1, 1, 0, 0, 0)), files[n], compress_type=method)


def dump(path):
    files, _ = read(path)
    x = files[SECTION].decode("utf-8")
    tables = find_tables(x)
    for i, (s, e) in enumerate(text_paragraphs(x)):
        runs = [re.sub(r"<[^>]+>", " ", t) for t in text_runs(x[s:e])]
        print("[문단 %d] %s" % (i, " ‖ ".join(runs)))
    for ti, (s, e) in enumerate(tables):
        tbl = x[s:e]
        print("\n[표 %d] %s행" % (ti, re.search(r'rowCnt="(\d+)"', tbl).group(1)))
        for rs, re_ in rows_of(tbl):
            tr = tbl[rs:re_]
            for cs, ce in cells_of(tr):
                tc = tr[cs:ce]
                r, c = cell_addr(tc)
                span = re.search(r'colSpan="(\d+)" rowSpan="(\d+)"', tc).groups()
                mark = "" if span == ("1", "1") else " (합침 가로%s 세로%s)" % span
                print("  %d:%d:%d%s  %s" % (ti, r, c, mark, plain_text(tc).replace("\n", " / ")))


def fill(src, spec_path, dst):
    files, order = read(src)
    x = files[SECTION].decode("utf-8")
    with open(spec_path, encoding="utf-8") as f:
        spec = json.load(f)

    # 표 칸 → 표 행 다시 만들기 → 본문 문단 순서로 바꾼다(뒤에서부터 바꿔 위치가 밀리지 않게)
    tables = find_tables(x)
    for ti in sorted(range(len(tables)), reverse=True):
        s, e = tables[ti]
        tbl = x[s:e]
        cell_edits = {k: v for k, v in spec.get("cells", {}).items() if int(k.split(":")[0]) == ti}
        if cell_edits:
            rws = rows_of(tbl)
            pieces, last = [], 0
            for rs, re_ in rws:
                tr = tbl[rs:re_]
                new_tr, l2 = [], 0
                for cs, ce in cells_of(tr):
                    tc = tr[cs:ce]
                    r, c = cell_addr(tc)
                    k = "%d:%d:%d" % (ti, r, c)
                    if k in cell_edits:
                        tc = set_cell_text(tc, cell_edits[k])
                    new_tr.append(tr[l2:cs] + tc)
                    l2 = ce
                new_tr.append(tr[l2:])
                pieces.append(tbl[last:rs] + "".join(new_tr))
                last = re_
            pieces.append(tbl[last:])
            tbl = "".join(pieces)
        delta = 0
        if str(ti) in spec.get("tables", {}):
            tbl, delta = rebuild_table(tbl, spec["tables"][str(ti)])
        x = x[:s] + tbl + x[e:]
        if delta:
            x = grow_box(x, s, delta)

    paras = text_paragraphs(x)
    for idx in sorted((int(k) for k in spec.get("paragraphs", {})), reverse=True):
        s, e = paras[idx]
        x = x[:s] + set_para_text(x[s:e], spec["paragraphs"][str(idx)]) + x[e:]

    # 줄 배치 정보는 한글이 열 때 다시 계산한다. 옛 값이 남으면 글자가 겹쳐 보일 수 있어 모두 지운다
    x = re.sub(r"<hp:linesegarray>.*?</hp:linesegarray>", "", x, flags=re.S)

    write(dst, files, order, x)
    print("만들었습니다:", dst)


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "dump" and len(sys.argv) == 3:
        dump(sys.argv[2])
    elif cmd == "fill" and len(sys.argv) == 5:
        fill(sys.argv[2], sys.argv[3], sys.argv[4])
    elif cmd == "text" and len(sys.argv) == 3:
        print(plain_text(read(sys.argv[2])[0][SECTION].decode("utf-8")))
    else:
        print(__doc__)
