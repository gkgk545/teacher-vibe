"""문항.json을 받아 구글 설문지 퀴즈를 만드는 Apps Script와 검토용 정답지, 문항표를 만든다.
파이썬 기본 기능만 쓴다(설치할 것 없음).

사용법
  python make_quiz.py 문항.json 결과폴더

문항.json 형식
{
  "title": "중1 과학 · 물질의 상태 변화 확인 퀴즈",
  "description": "학습지 2쪽까지 배운 내용입니다.",
  "items": [
    {"type": "객관식", "question": "...", "choices": ["...", "...", "...", "..."], "answer": 2,
     "explanation": "정답 해설 한두 문장", "source": "학습지 1쪽 '응고' 문단"},
    {"type": "주관식", "question": "... (두 글자)", "answer": "응고", "accept": ["응고"],
     "explanation": "...", "source": "학습지 1쪽 표"}
  ]
}
만드는 파일
  퀴즈설문지.gs   script.google.com 새 프로젝트에 붙여 넣고 실행
  정답지.html     인쇄·검토용
  문항표.csv      엑셀에서 열림(다른 퀴즈 플랫폼에 옮길 때)
"""
import csv
import html
import json
import os
import sys
from collections import Counter


def check(data):
    """만들기 전에 문항을 점검한다. 문제가 있으면 목록으로 돌려준다."""
    problems = []
    items = data.get("items", [])
    seen = set()
    for i, it in enumerate(items, 1):
        q = it.get("question", "").strip()
        if not q:
            problems.append("%d번: 발문이 비었습니다" % i)
        if q in seen:
            problems.append("%d번: 같은 발문이 또 있습니다" % i)
        seen.add(q)
        if not it.get("source"):
            problems.append("%d번: 근거(학습지 위치)가 없습니다" % i)
        if it.get("type") == "객관식":
            ch = it.get("choices", [])
            if len(ch) != 4 or any(not c.strip() for c in ch):
                problems.append("%d번: 보기는 빈칸 없이 4개여야 합니다" % i)
            if len(set(ch)) != len(ch):
                problems.append("%d번: 같은 보기가 두 번 있습니다" % i)
            if it.get("answer") not in (1, 2, 3, 4):
                problems.append("%d번: 정답은 1~4 중 하나여야 합니다" % i)
            if any(w in "".join(ch) for w in ("모두 정답", "정답 없음", "모두 옳다")):
                problems.append("%d번: '모두 정답' 같은 보기는 쓰지 않습니다" % i)
        elif it.get("type") == "주관식":
            a = str(it.get("answer", "")).strip()
            if not a or len(a) > 12:
                problems.append("%d번: 주관식 정답은 12자 이내 낱말이나 짧은 구절이어야 합니다" % i)
        else:
            problems.append("%d번: 유형은 '객관식' 또는 '주관식'이어야 합니다" % i)
    mc = [it["answer"] for it in items if it.get("type") == "객관식" and it.get("answer") in (1, 2, 3, 4)]
    if len(mc) >= 8:
        cnt = Counter(mc)
        most = max(cnt.values())
        if most > len(mc) * 0.4 or len(cnt) < 4:
            problems.append("객관식 정답 번호가 몰려 있습니다: %s (번호마다 고르게)" %
                            ", ".join("%d번 %d개" % (k, cnt.get(k, 0)) for k in (1, 2, 3, 4)))
    return problems


def js(s):
    return json.dumps(s, ensure_ascii=False)


def make_gs(data):
    lines = [
        "// 구글 설문지 퀴즈 만들기",
        "// 1) script.google.com → 새 프로젝트 → 이 내용을 모두 붙여 넣기",
        "// 2) 위쪽 '실행' → 권한 검토 → 내 계정 선택",
        "//    '확인되지 않은 앱' 화면이 나오면 '고급' → '(안전하지 않음)으로 이동' → '허용'",
        "//    (내가 붙여 넣은 스크립트가 내 드라이브에 설문지를 만드는 권한입니다)",
        "// 3) 아래 '실행 로그'에 나온 편집 주소와 학생용 주소를 엽니다",
        "// 주관식은 자동 채점 정답을 넣을 수 없어 배점과 정답 안내만 넣습니다.",
        "// 자동 채점하려면 설문지 편집 화면에서 문항마다 '답안'을 눌러 정답을 넣으세요.",
        "",
        "function makeQuiz() {",
        "  var form = FormApp.create(%s);" % js(data["title"]),
        "  form.setIsQuiz(true);",
        "  form.setDescription(%s);" % js(data.get("description", "")),
        "  form.setCollectEmail(false);",
        "  form.setShuffleQuestions(false);",
        "  var item;",
    ]
    for n, it in enumerate(data["items"], 1):
        title = "%d. %s" % (n, it["question"])
        if it["type"] == "객관식":
            lines += [
                "  item = form.addMultipleChoiceItem().setTitle(%s).setPoints(1).setRequired(true);" % js(title),
                "  item.setChoices([%s]);" % ", ".join(
                    "item.createChoice(%s, %s)" % (js(c), "true" if k == it["answer"] else "false")
                    for k, c in enumerate(it["choices"], 1)),
                "  item.setFeedbackForCorrect(FormApp.createFeedback().setText(%s).build());" % js(
                    "맞았습니다. " + it.get("explanation", "")),
                "  item.setFeedbackForIncorrect(FormApp.createFeedback().setText(%s).build());" % js(
                    "정답은 %d번 '%s'입니다. %s" % (it["answer"], it["choices"][it["answer"] - 1],
                                              it.get("explanation", ""))),
            ]
        else:
            lines += [
                "  item = form.addTextItem().setTitle(%s).setPoints(1).setRequired(true);" % js(title),
                "  item.setGeneralFeedback(FormApp.createFeedback().setText(%s).build());" % js(
                    "정답: %s. %s" % (" 또는 ".join(it.get("accept") or [it["answer"]]), it.get("explanation", ""))),
            ]
    lines += [
        "  Logger.log('편집 주소: ' + form.getEditUrl());",
        "  Logger.log('학생용 주소: ' + form.getPublishedUrl());",
        "}",
        "",
    ]
    return "\n".join(lines)


def make_html(data):
    rows = []
    for n, it in enumerate(data["items"], 1):
        if it["type"] == "객관식":
            ch = "<br>".join("%s %s" % ("①②③④"[k], html.escape(c)) for k, c in enumerate(it["choices"]))
            ans = "①②③④"[it["answer"] - 1]
        else:
            ch = "(주관식)"
            ans = html.escape(" / ".join(it.get("accept") or [it["answer"]]))
        rows.append("<tr><td>%d</td><td>%s</td><td>%s</td><td class=a>%s</td><td>%s</td><td class=s>%s</td></tr>" % (
            n, html.escape(it["question"]), ch, ans, html.escape(it.get("explanation", "")),
            html.escape(it.get("source", ""))))
    return """<!doctype html><html lang="ko"><meta charset="utf-8"><title>%s 정답지</title>
<style>body{font-family:sans-serif;margin:24px;color:#111}h1{font-size:20px}table{border-collapse:collapse;width:100%%;font-size:13px}
th,td{border:1px solid #999;padding:6px;vertical-align:top}th{background:#eee}.a{font-weight:bold;text-align:center}.s{color:#555;font-size:12px}
@media print{body{margin:0}}</style>
<h1>%s · 검토용 정답지</h1><p>%s</p>
<table><tr><th>번호</th><th>문제</th><th>보기</th><th>정답</th><th>해설</th><th>근거</th></tr>%s</table></html>""" % (
        html.escape(data["title"]), html.escape(data["title"]), html.escape(data.get("description", "")), "".join(rows))


def make_csv(data, path):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["유형", "문제", "보기1", "보기2", "보기3", "보기4", "정답", "해설", "근거"])
        for it in data["items"]:
            ch = it.get("choices", []) + [""] * (4 - len(it.get("choices", [])))
            w.writerow([it["type"], it["question"]] + ch[:4] + [it["answer"], it.get("explanation", ""), it.get("source", "")])


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if len(sys.argv) != 3:
        print(__doc__)
        return
    with open(sys.argv[1], encoding="utf-8") as f:
        data = json.load(f)
    problems = check(data)
    if problems:
        print("고칠 곳이 있어 만들지 않았습니다:")
        for p in problems:
            print(" -", p)
        sys.exit(1)
    out = sys.argv[2]
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "퀴즈설문지.gs"), "w", encoding="utf-8") as f:
        f.write(make_gs(data))
    with open(os.path.join(out, "정답지.html"), "w", encoding="utf-8") as f:
        f.write(make_html(data))
    make_csv(data, os.path.join(out, "문항표.csv"))
    mc = [it["answer"] for it in data["items"] if it["type"] == "객관식"]
    cnt = Counter(mc)
    print("만들었습니다: %s (객관식 %d, 주관식 %d, 정답 번호 %s)" % (
        out, len(mc), len(data["items"]) - len(mc), " ".join("%d번×%d" % (k, cnt.get(k, 0)) for k in (1, 2, 3, 4))))


if __name__ == "__main__":
    main()
